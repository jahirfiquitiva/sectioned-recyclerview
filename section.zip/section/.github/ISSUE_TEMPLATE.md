- [ ] I have verified there are no duplicate active or recent bugs, questions, or requests
- [ ] I have verified that I am using the latest version of this library.
- [ ] I have given my issue a non-generic title.

###### Include the following:
 - Library version: `x.x.x.x`
 - Device OS version: `6.0.1`
 - Device Manufacturer: `Huawei`
 - Device Name: `Nexus 6P`

Also, please wrap Java with correct syntax highlighting.

```java
System.out.println("Hello, world!");
```
 
###### Reproduction Steps

1. 
2. 
3. 

###### Expected Result



###### Actual Result

